r"""
Albers conic equal-area projection
==================================

This projection, developed by Heinrich C. Albers in 1805, is predominantly used
to map regions of large east-west extent, in particular the United States. It
is a conic, equal-area projection, in which parallels are unequally spaced arcs
of concentric circles, more closely spaced at the north and south edges of the
map. Meridians, on the other hand, are equally spaced radii about a common
center, and cut the parallels at right angles. Distortion in scale and shape
vanishes along the two standard parallels. Between them, the scale along
parallels is too small; beyond them it is too large. The opposite is true for
the scale along meridians.

**b**\ *lon0/lat0*\ /\ *lat1/lat2*\ */scale*
or **B**\ *lon0/lat0*\ /\ *lat1/lat2*\ */width*

- **b** or **B**: Sets the projection type.
- *lon0/lat0*: Sets the projection center.
- *lat1/lat2*: Sets the two standard parallels.
- *scale* or *width*: Sets the map size.
"""

# %%
import pygmt
from pygmt.params import Axis

fig = pygmt.Figure()
# Use the ISO country code for Brazil and add a padding of 2 degrees (+R2)
fig.coast(
    region="BR+R2",
    projection="B-55/-15/-25/0/12c",
    frame=Axis(annot=True, tick=True, grid=True),
    land="seagreen",
    water="gray90",
)
fig.show()

# sphinx_gallery_tags = ["equal-area"]
